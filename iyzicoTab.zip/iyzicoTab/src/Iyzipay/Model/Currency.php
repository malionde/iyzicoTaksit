<?php

namespace Iyzipay\Model;

class Currency
{
    const TL = "TRY";
    const EUR = "EUR";
    const USD = "USD";
    const GBP = "GBP";
    const IRR = "IRR";
    const NOK = "NOK";
    const RUB = "RUB";
    const CHF = "CHF";
}